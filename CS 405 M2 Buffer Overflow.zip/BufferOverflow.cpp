// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <string>
#include <cstring>

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;

  // TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
  //  even though it is a constant and the compiler buffer overflow checks are on.
  //  You need to modify this method to prevent buffer overflow without changing the account_number
  //  variable, and its position in the declaration. It must always be directly before the variable used for input.
  //  You must notify the user if they entered too much data.

  const std::string account_number = "CharlieBrown42"; //Unchanged, position unchanged (BME 3/20/2025)
  std::string input_filter; // Creates uninitialized temporary string variable for input, immediately following the account number (BME 3/20/2025)
  char user_input[20]; //Unchanged (BME 3/20/2025)

  std::cout << "Enter a value: "; // Unchanged (BME 3/20/2025)
  std::getline(std::cin, input_filter); // Gets user input, stores in variable "input_filter" (BME 3/20/2025)

  if(input_filter.length() > 19) { // If string length is longer than 19 characters, notifies user too much data was entered. (BME 3/20/2025)
      std::cout << "\n *** Warning: Input exceeded 19 character maximum. User input truncated. *** \n" << std::endl;
  }
  if (input_filter.length() > 1000) { // Terminates function if spam is detected, avoiding memory overload (BME 3/20/2025)
      std::cerr << "DoS attack detected, shutting down.";
      return(1);
  }

  std::strncpy(user_input, input_filter.c_str(), 19); // Copies first 19 chars from input_filter to user_input (BME 3/20/2025)

  user_input[19] = '\0'; // Sets 20th character in char array to termination '\0'  (BME 3/20/2025)
 
  std::cout << "You entered: " << user_input << std::endl; // Unchanged (BME 3/20/2025)
  std::cout << "Account Number = " << account_number << std::endl; // Unchanged (BME 3/20/2025)
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
