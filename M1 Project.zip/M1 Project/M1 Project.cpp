// NumericOverflows.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>     // std::cout
#include <limits>       // std::numeric_limits

template <typename T> // Added function that returns readable types (BME 3/4/2025)
std::string getTypeName()
{
    if (std::is_same<T, char>::value) return "char";
    if (std::is_same<T, signed char>::value) return "signed char";
    if (std::is_same<T, unsigned char>::value) return "unsigned char";
    if (std::is_same<T, short>::value) return "short";
    if (std::is_same<T, unsigned short>::value) return "unsigned short";
    if (std::is_same<T, int>::value) return "int";
    if (std::is_same<T, unsigned int>::value) return "unsigned int";
    if (std::is_same<T, long>::value) return "long";
    if (std::is_same<T, unsigned long>::value) return "unsigned long";
    if (std::is_same<T, long long>::value) return "long long";
    if (std::is_same<T, unsigned long long>::value) return "unsigned long long";
    if (std::is_same<T, float>::value) return "float";
    if (std::is_same<T, double>::value) return "double";
    if (std::is_same<T, long double>::value) return "long double";
    if (std::is_same<T, wchar_t>::value) return "wchar_t";

    return "Check for errors, no valid type used"; // (BME 3/4/2025)
}

/// <summary>
/// Template function to abstract away the logic of:
///   start + (increment * steps)
/// </summary>
/// <typeparam name="T">A type that with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="increment">How much to add each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <returns>start + (increment * steps)</returns>
template <typename T>
T add_numbers(T const& start, T const& increment, unsigned long int const& steps, bool &overflowStatus) // Added boolean argument for overflow status (BME 3/4/2025)
{
    T result = start;
    T overFlowCheck = std::numeric_limits<T>::max() - increment; // Calculates a value to compare against the result for overflow detection (BME 3/4/2025)
    overflowStatus = false; // Creates and initializes overflow check variable (BME 3/4/2025)

    for (unsigned long int i = 0; i < steps; ++i)
    {
        if (result > overFlowCheck) {   // Detects overflow (BME 3/4/2025)
            overflowStatus = true;
            return result;  // returns result if overflow is detected (BME 3/9/2025)
        }
        if (!overflowStatus) { // If no overflow projected, increments result (BME 3/9/2025)
            result += increment;
        }
    }

    return result; //  returns results after increment (BME 3/9/2025)
}

/// <summary>
/// Template function to abstract away the logic of:
///   start - (increment * steps)
/// </summary>
/// <typeparam name="T">A type that with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="increment">How much to subtract each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <returns>start - (increment * steps)</returns>

template <typename T>
T subtract_numbers(T const& start, T const& decrement, unsigned long int const& steps, bool &underflowStatus)
{
    T result = start;
    underflowStatus = false; // Creates and initializes overflow check variable (BME 3/4/2025)

    for (unsigned long int i = 0; i < steps; ++i) {

        //std::cout << "DEBUG: Result: " << +result << std::endl; // Manual DEBUG Statement, saved for later use (BME 3/5/2025)
        
        if (std::numeric_limits<T>::is_signed) { // underflow detection conditions for signed integers (BME 3/5/2025)
            //std::cout << "\n\n DEBUG: ENTERED SIGNED CONDITION\n" << std::endl;     // Manual DEBUG Statement, saved for later use (BME 3/5/2025)
            if (result < std::numeric_limits<T>::min() + decrement)
            {
                underflowStatus = true;
                return result;  // Return current value before underflow occurs (BME 3/9/2025)
            }
        }
        else { // underflow detection conditions for unsigned integers (BME 3/5/2025)
            //std::cout << "\n\n DEBUG: ENTERED UNSIGNED CONDITION\n" << std::endl; // Manual DEBUG Statement, saved for later use (BME 3/5/2025)
            if (result < decrement) {
                underflowStatus = true;
                return result;
            }
        }
        result -= decrement; // Decrements result if no overflow projected (BME 3/9/2025)
                
    }

    return result;
}


//  NOTE:
//    You will see the unary ('+') operator used in front of the variables in the test_XXX methods.
//    This forces the output to be a number for cases where cout would assume it is a character. 

template <typename T>
void test_overflow()
{

    bool overflowStatus; // Overflow detection variable (BME 3/4/2025)
    // TODO: The add_numbers template function will overflow in the second method call
    //        You need to change the add_numbers method to:
    //        1. Detect when an overflow will happen
    //        2. Prevent it from happening
    //        3. Return the correct value when no overflow happened or
    //        4. Return something to tell test_overflow the addition failed
    //        NOTE: The add_numbers method must remain a template in the NumericFunctions header.
    //
    //        You need to change the test_overflow method to:
    //        1. Detect when an add_numbers failed
    //        2. Inform the user the overflow happened
    //        3. A successful result displays the same result as before you changed the method
    //        NOTE: You cannot change anything between START / END DO NOT CHANGE
    //              The test_overflow method must remain a template in the NumericOverflows source file
    //
    //  There are more than one possible solution to this problem. 
    //  The solution must work for all of the data types used to call test_overflow() in main().

    // START DO NOT CHANGE
    //  how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we add each step (result should be: start + (increment * steps))
    const T increment = std::numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = 0;

    std::cout << "Overflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    std::cout << "\tAdding Numbers Without Overflow (" << +start << ", " << +increment << ", " << steps << ") = ";
    T result = add_numbers<T>(start, increment, steps, overflowStatus);
    std::cout << +result << std::endl;

    std::cout << "\tAdding Numbers With Overflow (" << +start << ", " << +increment << ", " << (steps + 1) << ") = ";
    result = add_numbers<T>(start, increment, steps + 1, overflowStatus);
    std::cout << +result << std::endl;
    if (overflowStatus) { // Overflow detection warning trigger (BME 3/4/2025)
        std::cerr << "\n *** Caution: Operation caused an overflow using type \""
            << getTypeName<T>()
            << "\", previous value returned to avoid overflow. ***\n\n";
    }
}

template <typename T>
void test_underflow()
{
    bool underflowStatus = false; // underflow detection variable (BME 3/4/2025)
    // TODO: The subtract_numbers template function will underflow in the second method call
    //        You need to change the subtract_numbers method to:
    //        1. Detect when an underflow will happen
    //        2. Prevent it from happening
    //        3. Return the correct value when no underflow happened or
    //        4. Return something to tell test_underflow the subtraction failed
    //        NOTE: The subtract_numbers method must remain a template in the NumericFunctions header.
    //
    //        You need to change the test_underflow method to:
    //        1. Detect when an subtract_numbers failed
    //        2. Inform the user the underflow happened
    //        3. A successful result displays the same result as before you changed the method
    //        NOTE: You cannot change anything between START / END DO NOT CHANGE
    //              The test_underflow method must remain a template in the NumericOverflows source file
    //
    //  There are more than one possible solution to this problem. 
    //  The solution must work for all of the data types used to call test_overflow() in main().

    // START DO NOT CHANGE
    //  how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we subtract each step (result should be: start - (increment * steps))
    const T decrement = std::numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = std::numeric_limits<T>::max();

    std::cout << "Underflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    std::cout << "\tSubtracting Numbers Without Underflow (" << +start << ", " << +decrement << ", " << steps + 6 << ") = "; // Modified number of steps to induce negative values of signed integers (BME 3/5/2025)
    auto result = subtract_numbers<T>(start, decrement, steps + 6, underflowStatus); // Modified number of steps to induce negative values of signed integers (BME 3/5/2025)
    std::cout << +result << std::endl;

    std::cout << "\tSubtracting Numbers With Underflow (" << +start << ", " << +decrement << ", " << (steps + 7) << ") = "; // Modified number of steps to induce underflow of signed integers (BME 3/5/2025)
    result = subtract_numbers<T>(start, decrement, steps + 7, underflowStatus); // Modified number of steps to induce underflow of signed integers (BME 3/5/2025)
    std::cout << +result << std::endl;
    if (underflowStatus) { // underflow detection warning trigger (BME 3/5/2025)
        std::cerr << "\n *** Caution: Operation caused an underflow using type \""
            << getTypeName<T>()
            << "\", previous value returned to avoid underflow. ***\n\n";
    }
}

void do_overflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Overflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primative times see: https://www.geeksforgeeks.org/c-data-types/
    // signed integers
    test_overflow<char>();
    test_overflow<wchar_t>();
    test_overflow<short int>();
    test_overflow<int>();
    test_overflow<long>();
    test_overflow<long long>();

    // unsigned integers
    test_overflow<unsigned char>();
    test_overflow<unsigned short int>();
    test_overflow<unsigned int>();
    test_overflow<unsigned long>();
    test_overflow<unsigned long long>();

    // real numbers
    test_overflow<float>();
    test_overflow<double>();
    test_overflow<long double>();
}

void do_underflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Underflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primative times see: https://www.geeksforgeeks.org/c-data-types/
    // signed integers
    test_underflow<char>();
    test_underflow<wchar_t>();
    test_underflow<short int>();
    test_underflow<int>();
    test_underflow<long>();
    test_underflow<long long>();

    // unsigned integers
    test_underflow<unsigned char>();
    test_underflow<unsigned short int>();
    test_underflow<unsigned int>();
    test_underflow<unsigned long>();
    test_underflow<unsigned long long>();

    // real numbers
    test_underflow<float>();
    test_underflow<double>();
    test_underflow<long double>();
}

/// <summary>
/// Entry point into the application
/// </summary>
/// <returns>0 when complete</returns>
int main()
{
    //  create a string of "*" to use in the console
    const std::string star_line = std::string(50, '*');

    std::cout << "Starting Numeric Underflow / Overflow Tests!" << std::endl;

    // run the overflow tests
    do_overflow_tests(star_line);

    // run the underflow tests
    do_underflow_tests(star_line);

    std::cout << std::endl << "All Numeric Underflow / Overflow Tests Complete!" << std::endl;

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu